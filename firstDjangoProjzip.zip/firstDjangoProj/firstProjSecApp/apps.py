from django.apps import AppConfig


class FirstprojsecappConfig(AppConfig):
    name = 'firstProjSecApp'
