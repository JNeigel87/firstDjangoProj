# from django.shortcuts import render, HttpResponse, redirect
# def index(request):
#     return HttpResponse("this is the second app!")

# def another_method(request, my_val):
#     return HttpResponse("this is the second app project!")


# # Create your views here.
