# from django.urls import path
# from . import views
# urlpatterns = [
#     path('firstProj', views.index),
#     path('', views.another_method),
# ]