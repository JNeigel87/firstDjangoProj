from django.apps import AppConfig


class FirstdjangoprojappConfig(AppConfig):
    name = 'firstDjangoProjApp'
