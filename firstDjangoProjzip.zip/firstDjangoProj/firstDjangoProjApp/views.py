from django.shortcuts import render, HttpResponse, redirect
def index(request):
    # return HttpResponse("Django Project Page")
    return redirect("/blogs")

# def root(request):
#     )

def index_method(request):
    return HttpResponse("placeholder to later display a list of all the blogs")

def new(request):
    return HttpResponse("place holder to display a new form to creat a new blog")

def create(request):
    return redirect("/")

def show(request, num):
    return HttpResponse(f"placeholder to display blog number {num}")

def edit(request, num):
    return HttpResponse(f"placeholder to edit blog {num}")

def destroy(request, num):
    return redirect("/blogs")

def json(request):
    return JsonResponse({"response": "JSON response from blogs", "status": True})



# Create your views here.
